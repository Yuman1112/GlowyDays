import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/ValidateOtp")
public class ValidateOtp extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession mySession = request.getSession();
        // get user input OTP
        int value = Integer.parseInt(request.getParameter("otp"));

        // get session OTP
        HttpSession session = request.getSession();
        int otp = (int) session.getAttribute("otp");

        // validate OTP
        if (value == otp) {
            // if OTP match，-> NewPassword.jsp
            request.setAttribute("email", request.getParameter("email"));
            request.setAttribute("status", "success");
            response.sendRedirect("JSP/NewPassword.jsp");  // 使用重定向
        } else {
            // if OTP not match，-> EnterOTP.jsp 
            mySession.setAttribute("message", "<span style='color:red;'>OTP Wrong. Please try again</span>");
            response.sendRedirect("/GlowyDays/JSP/EnterOTP.jsp");
        }
    }
}
