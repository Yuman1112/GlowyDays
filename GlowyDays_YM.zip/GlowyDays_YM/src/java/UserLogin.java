import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import dao.LoginDAO;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpSession;
import model.Login;
import model.User;

@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String email = request.getParameter("email");
            String password = request.getParameter("password");

            // Create a Login object and set email and password
            Login login = new Login();
            login.setEmail(email);
            login.setPassword(password);

            // Create an instance of LoginDAO to check if the user exists in the database
            LoginDAO loginDAO = new LoginDAO();
            boolean isLogin = loginDAO.loginUser(login,request);

            // Check if login is successful
            if (isLogin) {
                response.sendRedirect("/GlowyDays/JSP/UserHome.jsp");
            } else {
                out.println("Registration Failed!");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}