package dao;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import java.sql.*;
import model.Login;
import model.User;

public class LoginDAO {

    public boolean loginUser(Login login, HttpServletRequest request) {
        boolean isLogin = false;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/Client", "nbuser", "nbuser");

            String sql = "SELECT * FROM \"USER\" WHERE \"email\" = ? AND \"password\" = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, login.getEmail());
            pst.setString(2, login.getPassword());

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                isLogin = true;
                String name = rs.getString("name");  
                String username = rs.getString("username");
                String birth = rs.getString("birth");
                String email = rs.getString("email");
                String mobileNo = rs.getString("mobileNo");

                HttpSession session = request.getSession();
                session.setAttribute("name", name);
                session.setAttribute("username", username);
                session.setAttribute("birth", birth);
                session.setAttribute("email", email);
                session.setAttribute("mobileNo", mobileNo);
            }

            rs.close();
            pst.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return isLogin;
    }

    public boolean isEmailRegistered(String email) {
        boolean exists = false;

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/Client", "nbuser", "nbuser");

            String sql = "SELECT * FROM \"USER\" WHERE \"email\" = ?";
            PreparedStatement pst = con.prepareStatement(sql);
            pst.setString(1, email);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                exists = true;
            }

            rs.close();
            pst.close();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return exists;
    }
}
